/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Purchase;
import java.util.Collections;
import java.util.List;
import org.hibernate.*;

/**
 *
 * @author Admin
 */
public class PurchaseDao {

    public String newpurchase(Purchase purchase) {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();

        ss.save(purchase);
        tr.commit();

        ss.close();
        return "saved";

    }

    public String updatepurchase(Purchase purchase) {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();

        ss.update(purchase);
        tr.commit();

        ss.close();
        return "updated";

    }

    public String deletepurchase(Purchase purchase) {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();

        ss.delete(purchase);
        tr.commit();

        ss.close();
        return "deleted";

    }

    public List<Purchase> allPurchases() {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Purchase> purchases = ss.createQuery("select pur from Purchase pur").list();
        ss.close();
        return purchases;

    }

    public Purchase getpurchase(Purchase purchase) {

        Session ss = HibernateUtil.getSessionFactory().openSession();
        Purchase pur = (Purchase) ss.get(Purchase.class, purchase.getPurchaseId());
        ss.close();
        return pur;

    }

    public List<Purchase> retrieveTableData(){
        List<Purchase> tableData;
        try{
            Session ss = HibernateUtil.getSessionFactory().openSession();
            Query query = ss.createQuery("FROM Purchase");
            tableData = query.list();
        } catch (Exception e) {
            e.printStackTrace();
            tableData = Collections.emptyList();
        }
        return tableData;
    }    
}
