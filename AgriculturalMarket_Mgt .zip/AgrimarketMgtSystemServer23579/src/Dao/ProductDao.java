/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;


import Model.Product;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Admin
 */
public class ProductDao {
    
    public String newproduct(Product product){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.save(product);
        tr.commit();
        
        ss.close();
        return "saved";
        
    }
    public String updateproduct(Product product){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.update(product);
        tr.commit();
        
        ss.close();
        return "updated";
        
    }
    public String deleteproduct(Product product){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.delete(product);
        tr.commit();
        
        ss.close();
        return "deleted";
        
    }
    public List<Product> allproducts(){
     
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Product> products = ss.createQuery("select pro from Product pro").list();
        ss.close();
        return products;
        
    }
    public Product getproduct(Product product){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Product pro = (Product)ss.get(Product.class, product.getProductId());
        ss.close();
        return pro;
        
    }
}
