/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service.Implementation;

import Dao.ProductDao;
import Model.Product;
import Service.ProductService;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 *
 * @author Admin
 */
public class ProductImpl extends UnicastRemoteObject implements ProductService{

    public ProductImpl()throws RemoteException{
        super();
    }
    
    public ProductDao dao = new ProductDao();
    
    @Override
    public String newpoduct(Product product) throws RemoteException {
        return dao.newproduct(product);
    }

    @Override
    public String updateproduct(Product product) throws RemoteException {
        return dao.updateproduct(product);
    }

    @Override
    public String deleteproduct(Product product) throws RemoteException {
        return dao.deleteproduct(product);
    }

    @Override
    public List<Product> getProducts() throws RemoteException {
        return dao.allproducts();
    }

    @Override
    public Product getProduct(Product product) throws RemoteException {
        return dao.getproduct(product);
    }
    
}
