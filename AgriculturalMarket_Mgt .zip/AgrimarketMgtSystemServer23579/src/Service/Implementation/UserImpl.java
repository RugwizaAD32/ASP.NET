/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service.Implementation;

import Dao.UserDao;
import Model.User;
import Service.UserService;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 *
 * @author Admin
 */
public class UserImpl extends UnicastRemoteObject implements UserService{

    public UserImpl()throws RemoteException{
        super();
    }
    
    public UserDao dao = new UserDao();
    
    @Override
    public String newuser(User user) throws RemoteException {
        return dao.newuser(user);
    }

    @Override
    public String updateuser(User user) throws RemoteException {
        return dao.updateuser(user);
    }

    @Override
    public String deleteuser(User user) throws RemoteException {
        return dao.deleteuser(user);
    }

    @Override
    public List<User> getUsers() throws RemoteException {
        return dao.allUsers();
    }

    @Override
    public List<User> Login(String username, String password) throws RemoteException {
        return dao.Login(username, password);
    }
    
}
