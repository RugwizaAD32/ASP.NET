/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service.Implementation;

import Dao.PurchaseDao;
import Model.Purchase;
import Service.PurchaseService;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 *
 * @author Admin
 */
public class PurchaseImpl extends UnicastRemoteObject implements PurchaseService{

    public PurchaseImpl() throws RemoteException{
        super();
    }
    
    public PurchaseDao dao = new PurchaseDao();
    
    @Override
    public String newpurchase(Purchase purchase) throws RemoteException {
        return dao.newpurchase(purchase);
    }

    @Override
    public String updatepurchase(Purchase purchase) throws RemoteException {
        return dao.updatepurchase(purchase);
    }

    @Override
    public String deletepurchase(Purchase purchase) throws RemoteException {
        return dao.deletepurchase(purchase);
    }

    @Override
    public List<Purchase> getallPurchases() throws RemoteException {
        return dao.allPurchases();
    }

    @Override
    public Purchase getpurchase(Purchase purchase) throws RemoteException {
        return dao.getpurchase(purchase);
    }

    @Override
    public List<Purchase> retrieveTableData() throws RemoteException {
        return dao.retrieveTableData();
    }
    
}
