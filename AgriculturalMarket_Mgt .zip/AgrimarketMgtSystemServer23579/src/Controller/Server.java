/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Service.Implementation.ProductImpl;
import Service.Implementation.PurchaseImpl;
import Service.Implementation.UserImpl;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Admin
 */
public class Server{
    
    
    public static void main(String[] args) {
        try {
            
            System.setProperty("java.rmi.server.hostname", "127.0.0.1");
            Registry registry = LocateRegistry.createRegistry(5000);
            
            registry.rebind("purchase", new PurchaseImpl());
            registry.rebind("product", new ProductImpl());
            registry.rebind("user", new UserImpl());
            
            System.out.println("Running on port 5000");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
